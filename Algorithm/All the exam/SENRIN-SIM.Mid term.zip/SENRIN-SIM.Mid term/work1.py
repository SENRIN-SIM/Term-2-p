result=""
i=0
sum=0
while i < 5:
    n=int(input())
    i+=1
if n >=10 and n<=30:
    result="WON" 
else:
    result="LOST"
print(result)



